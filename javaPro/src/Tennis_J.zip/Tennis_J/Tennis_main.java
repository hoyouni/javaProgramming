package Tennis_J;

public class Tennis_main {
	public static void main(String[] args) {
		Tennis_Score TP = new Tennis_Score();
		TP.gameStyle();
		TP.manOrWoman();
		TP.gamePeopleName();
		TP.score();
	}
}

